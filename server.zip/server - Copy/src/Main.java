public class Main {
    public static void main(String[] args) {
        Server server = new Server(14200, 1000, 100);
    }
}
