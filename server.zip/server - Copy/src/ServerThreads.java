import java.io.*;
import java.net.Socket;

public class ServerThreads extends Thread{
    Socket socket;
    int clientID;
    int sleeppingTime;
    DataInputStream inputStream;
    DataOutputStream outputStream;

    public ServerThreads(Socket socket, int clientID, int sleeppingTime) {
        this.socket = socket;
        this.clientID = clientID;
        this.sleeppingTime = sleeppingTime;
    }

    @Override
    public void run() {
        try {
            inputStream = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            outputStream = new DataOutputStream(socket.getOutputStream());
            // multiple message for same client
            while (true) {
                int fromBase = inputStream.readInt();
                int toBase = inputStream.readInt();
                String number = inputStream.readUTF();
                System.out.println(clientID + " is sent  number = " + number);

                if (number == null) {
                    try {
                        System.out.println("Connection closed with " + clientID);
                        socket.close();
                        inputStream.close();

                        Server.freeClients(clientID);
                        break;
                    } catch (IOException ioException) {
                        System.out.println(ioException);
                    }
                }

                BaseConversion baseConversion = new BaseConversion();
                String str = baseConversion.decimalToBase(baseConversion.anyBaseToDecimal(number,fromBase),toBase);
                System.out.println(str);
                outputStream.writeUTF(str);

                Thread.sleep(sleeppingTime);
            }
        } catch (IOException | InterruptedException exception) {
            System.out.println(exception);
        }

        // close client socket if client connection is broken
        try {
            this.socket.close();
        } catch (IOException ioException) {
            System.out.println(ioException);
        }
    }
}
